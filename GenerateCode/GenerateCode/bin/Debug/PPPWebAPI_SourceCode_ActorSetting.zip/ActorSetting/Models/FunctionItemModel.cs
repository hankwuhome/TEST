using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class FunctionItemModel : _BaseModel	 
    {													 
        #region Properties                                
        public int FunctionItemNO { get; set;}  
        public int FunctionNO { get; set;}  
        public string FunctionItemName { get; set;}  
        public string FunctionItemCD { get; set;}  
        public string FunctionItemUrl { get; set;}  
        public string IsDefaultEntry { get; set;}  
        #endregion										  
    }													 
}														 
