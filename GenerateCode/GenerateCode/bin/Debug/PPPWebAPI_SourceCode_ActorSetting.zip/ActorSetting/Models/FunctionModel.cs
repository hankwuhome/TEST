using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class FunctionModel : _BaseModel	 
    {													 
        #region Properties                                
        public int FunctionNO { get; set;}  
        public string FunctionCD { get; set;}  
        public string FunctionName { get; set;}  
        public int FunctionGroupNO { get; set;}  
        public int EntryFunctionItemNO { get; set;}  
        public string EntryFunctionItemOpenType { get; set;}  
        public int SortSeq { get; set;}  
        public string IsMenu { get; set;}  
        #endregion										  
    }													 
}														 
