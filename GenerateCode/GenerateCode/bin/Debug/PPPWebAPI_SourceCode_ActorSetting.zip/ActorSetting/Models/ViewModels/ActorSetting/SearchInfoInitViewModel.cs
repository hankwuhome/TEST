using System;                                            
using System.Collections.Generic;						 
using System.ComponentModel;							 
using System.Linq;										 
using System.Web;										 
using PPPWEBAPI.Extensions;								 
														 
namespace PPPWEBAPI.Models.ViewModels.ActorSetting 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class SearchInfoInitViewModel				 
    {													 
        #region Enums									 
														 
        #endregion										 
														 
        #region Properties								 
														 
        #endregion										 
														 
        #region Public Methods							 
														 
        #endregion										 
    }													 
}														 
