using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class ActorFunctionModel : _BaseModel	 
    {													 
        #region Properties                                
        public string ActorID { get; set;}  
        public int FunctionNO { get; set;}  
        #endregion										  
    }													 
}														 
