using System;																						
using System.Collections.Generic;																	
using System.Linq;																					
using System.Text;																					
using System.Threading.Tasks;																		
using PPPWEBAPI.Models;																				
using PPPWEBAPI.Models.ViewModels.ActorSetting;												
namespace PPPWEBAPI.Repositories.Interfaces															
{																									
    interface IFunctionGroupRepository : _IBaseRepository<FunctionGroupModel>						
    {																								
        bool AddFunctionGroup(FunctionGroupModel model);							
        bool UpdateFunctionGroup(FunctionGroupModel model);							
        bool DeleteFunctionGroup(FunctionGroupModel model);							
    }																								
}																									
