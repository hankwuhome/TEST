using System;																						
using System.Collections.Generic;																	
using System.Linq;																					
using System.Text;																					
using System.Threading.Tasks;																		
using PPPWEBAPI.Models;																				
using PPPWEBAPI.Models.ViewModels.ActorSetting;												
namespace PPPWEBAPI.Repositories.Interfaces															
{																									
    interface IFunctionItemRepository : _IBaseRepository<FunctionItemModel>						
    {																								
        bool AddFunctionItem(FunctionItemModel model);							
        bool UpdateFunctionItem(FunctionItemModel model);							
        bool DeleteFunctionItem(FunctionItemModel model);							
    }																								
}																									
