//#region Import											
import { Component } from '@angular/core';					
//#endregin													
															
//#region Definition										
@Component({												
    selector: 'DeviceSellPriceSetting-Base',					
    templateUrl: '../../Views/DeviceSellPriceSetting/Base.html'	
})															
//#endregin													
															
//#region Class												
export class BaseController {}								
//#endregin													
