using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class BrandModel : _BaseModel	 
    {													 
        #region Properties                                
        public string BrandCD { get; set;}  
        public string BrandName { get; set;}  
        #endregion										  
    }													 
}														 
