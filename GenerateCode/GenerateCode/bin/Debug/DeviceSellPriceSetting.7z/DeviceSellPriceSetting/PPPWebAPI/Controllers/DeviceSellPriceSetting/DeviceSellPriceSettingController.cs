using System;															
using System.Collections.Generic;										
using System.Linq;														
using System.Net;														
using System.Net.Http;													
using System.Web.Http;													
using PPPWEBAPI.Models.ViewModels.DeviceSellPriceSetting;					
using PPPWEBAPI.Models;													
																		
namespace PPPWEBAPI.Controllers.DeviceSellPriceSetting						
{																		
    public partial class DeviceSellPriceSettingController : _BaseController	
    {																	
        #region Properties												
        #endregion														
    }																	
}																		
