using System;																						
using System.Collections.Generic;																	
using System.Linq;																					
using System.Text;																					
using System.Threading.Tasks;																		
using PPPWEBAPI.Models;																				
using PPPWEBAPI.Models.ViewModels.AccountSetting;												
namespace PPPWEBAPI.Repositories.Interfaces															
{																									
    interface IUserLogRepository : _IBaseRepository<UserLogModel>						
    {																								
        bool AddUserLog(UserLogModel model);							
        bool UpdateUserLog(UserLogModel model);							
        bool DeleteUserLog(UserLogModel model);							
    }																								
}																									
