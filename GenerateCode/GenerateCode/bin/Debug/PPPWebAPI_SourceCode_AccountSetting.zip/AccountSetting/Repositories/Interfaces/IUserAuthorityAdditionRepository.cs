using System;																						
using System.Collections.Generic;																	
using System.Linq;																					
using System.Text;																					
using System.Threading.Tasks;																		
using PPPWEBAPI.Models;																				
using PPPWEBAPI.Models.ViewModels.AccountSetting;												
namespace PPPWEBAPI.Repositories.Interfaces															
{																									
    interface IUserAuthorityAdditionRepository : _IBaseRepository<UserAuthorityAdditionModel>						
    {																								
        bool AddUserAuthorityAddition(UserAuthorityAdditionModel model);							
        bool UpdateUserAuthorityAddition(UserAuthorityAdditionModel model);							
        bool DeleteUserAuthorityAddition(UserAuthorityAdditionModel model);							
    }																								
}																									
