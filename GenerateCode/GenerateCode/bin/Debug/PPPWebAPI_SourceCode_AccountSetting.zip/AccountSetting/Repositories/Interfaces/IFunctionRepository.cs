using System;																						
using System.Collections.Generic;																	
using System.Linq;																					
using System.Text;																					
using System.Threading.Tasks;																		
using PPPWEBAPI.Models;																				
using PPPWEBAPI.Models.ViewModels.AccountSetting;												
namespace PPPWEBAPI.Repositories.Interfaces															
{																									
    interface IFunctionRepository : _IBaseRepository<FunctionModel>						
    {																								
        bool AddFunction(FunctionModel model);							
        bool UpdateFunction(FunctionModel model);							
        bool DeleteFunction(FunctionModel model);							
    }																								
}																									
