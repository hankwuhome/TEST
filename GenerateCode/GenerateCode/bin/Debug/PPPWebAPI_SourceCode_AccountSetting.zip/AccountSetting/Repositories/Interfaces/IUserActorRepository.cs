using System;																						
using System.Collections.Generic;																	
using System.Linq;																					
using System.Text;																					
using System.Threading.Tasks;																		
using PPPWEBAPI.Models;																				
using PPPWEBAPI.Models.ViewModels.AccountSetting;												
namespace PPPWEBAPI.Repositories.Interfaces															
{																									
    interface IUserActorRepository : _IBaseRepository<UserActorModel>						
    {																								
        bool AddUserActor(UserActorModel model);							
        bool UpdateUserActor(UserActorModel model);							
        bool DeleteUserActor(UserActorModel model);							
    }																								
}																									
