using System;																						
using System.Collections.Generic;																	
using System.Linq;																					
using System.Text;																					
using System.Threading.Tasks;																		
using PPPWEBAPI.Models;																				
using PPPWEBAPI.Models.ViewModels.AccountSetting;												
namespace PPPWEBAPI.Repositories.Interfaces															
{																									
    interface IAccountRepository : _IBaseRepository<AccountModel>						
    {																								
        SearchListViewModel QuerySearchList(SearchInfoViewModel searchInfo); 
        DetailViewModel QueryDetail(DetailRequestViewModel detailRequest);	
        bool AddAccount(AccountModel model);							
        bool UpdateAccount(AccountModel model);							
        bool DeleteAccount(AccountModel model);							
    }																								
}																									
