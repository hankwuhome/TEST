using System;                                            
using System.Collections.Generic;						 
using System.ComponentModel;							 
using System.Linq;										 
using System.Web;										 
using PPPWEBAPI.Extensions;								 
														 
namespace PPPWEBAPI.Models.ViewModels.AccountSetting 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class SearchInfoViewModel:_BaseSearchInfoViewModel				 
    {													 
        #region Enums									 
        //要先定義SQL Sort排序欄位
        public enum EnumSort                                  
        {													  
            [Description("ORDER BY ")] 
            DEFAULT,										  
        }													  
        #endregion										 
														 
        #region Properties								 
														 
        #endregion										 
														 
        #region Public Methods							 
														 
        #endregion										 
    }													 
}														 
