using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class UserFunctionModel : _BaseModel	 
    {													 
        #region Properties                                
        public string UserID { get; set;}  
        public int FunctionNO { get; set;}  
        public string RequirementNO { get; set;}  
        public string IsDelete { get; set;}  
        #endregion										  
    }													 
}														 
