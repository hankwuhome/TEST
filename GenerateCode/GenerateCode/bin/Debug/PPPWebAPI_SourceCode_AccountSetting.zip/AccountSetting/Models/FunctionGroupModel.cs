using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class FunctionGroupModel : _BaseModel	 
    {													 
        #region Properties                                
        public int FunctionGroupNO { get; set;}  
        public string FunctionGroupCD { get; set;}  
        public string FunctionGroupName { get; set;}  
        public int SortSeq { get; set;}  
        #endregion										  
    }													 
}														 
