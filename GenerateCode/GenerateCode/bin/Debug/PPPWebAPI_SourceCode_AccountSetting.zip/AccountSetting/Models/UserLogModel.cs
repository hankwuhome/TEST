using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class UserLogModel : _BaseModel	 
    {													 
        #region Properties                                
        public int LogNO { get; set;}  
        public string UserID { get; set;}  
        public string LogType { get; set;}  
        public string LogMemo { get; set;}  
        public DateTime CreateDate { get; set;}  
        public string CreateUserID { get; set;}  
        #endregion										  
    }													 
}														 
