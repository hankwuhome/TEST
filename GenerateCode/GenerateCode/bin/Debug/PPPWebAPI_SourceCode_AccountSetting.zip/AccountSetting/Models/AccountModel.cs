using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class AccountModel : _BaseModel	 
    {													 
        #region Properties                                
        public string Account { get; set;}  
        public string Password { get; set;}  
        public string AccountType { get; set;}  
        public string AccountName { get; set;}  
        public string IsDelete { get; set;}  
        public DateTime CreateDate { get; set;}  
        public string CreateUserID { get; set;}  
        public DateTime UpdateDate { get; set;}  
        public string UpdateUserID { get; set;}  
        public string RequirementNO { get; set;}  
        public DateTime EffectiveStartDate { get; set;}  
        public DateTime EffectiveEndDate { get; set;}  
        public string AccountStatus { get; set;}  
        #endregion										  
    }													 
}														 
