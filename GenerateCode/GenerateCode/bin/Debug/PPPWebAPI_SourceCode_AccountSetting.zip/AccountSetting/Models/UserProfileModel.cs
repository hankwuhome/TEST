using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class UserProfileModel : _BaseModel	 
    {													 
        #region Properties                                
        public string UserID { get; set;}  
        public string Account { get; set;}  
        public string UserName { get; set;}  
        public string DepartmentCD { get; set;}  
        public string ManagerUserID { get; set;}  
        public string Email { get; set;}  
        public DateTime InDate { get; set;}  
        public DateTime OutDate { get; set;}  
        public string JobStatus { get; set;}  
        #endregion										  
    }													 
}														 
