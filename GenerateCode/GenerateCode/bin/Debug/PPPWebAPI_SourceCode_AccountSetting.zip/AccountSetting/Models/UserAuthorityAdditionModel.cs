using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class UserAuthorityAdditionModel : _BaseModel	 
    {													 
        #region Properties                                
        public string UserID { get; set;}  
        public string DepartmentCD { get; set;}  
        public string RequirementNO { get; set;}  
        public string IsDelete { get; set;}  
        #endregion										  
    }													 
}														 
