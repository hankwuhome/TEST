using System;                                            
using System.Collections.Generic;						 
using System.Linq;										 
using System.Web;										 
														 
namespace PPPWEBAPI.Models								 
{														 
    /// <summary>										 
    /// 									   
    /// </summary>										 
    public class UserActorModel : _BaseModel	 
    {													 
        #region Properties                                
        public string UserID { get; set;}  
        public string ActorID { get; set;}  
        public string UserActorStatus { get; set;}  
        public string CreateUserID { get; set;}  
        public DateTime CreateDate { get; set;}  
        public string UpdateUserID { get; set;}  
        public DateTime UpdateDate { get; set;}  
        public string RequirementNO { get; set;}  
        public string IsDelete { get; set;}  
        #endregion										  
    }													 
}														 
