//#region Import											
import { Component } from '@angular/core';					
//#endregin													
															
//#region Definition										
@Component({												
    selector: 'ActorSetting-Base',					
    templateUrl: '../../Views/ActorSetting/Base.html'	
})															
//#endregin													
															
//#region Class												
export class BaseController {}								
//#endregin													
