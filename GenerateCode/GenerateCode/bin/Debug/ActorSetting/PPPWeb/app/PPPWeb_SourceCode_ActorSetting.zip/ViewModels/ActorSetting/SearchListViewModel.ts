//#region Common Import									
import { PageViewModel } from '../BaseViewModel';		 
//#endregion											 
														 
//#region Class											 
export class SearchInfoInitViewModel {					 
														 
}														 
														 
export class SearchInfoViewModel extends PageViewModel  {
														 
}														 
														 
export class SearchListViewModel extends PageViewModel { 
    SearchItemList: SearchItemViewModel[]= [];			 
}														 
														 
export class SearchItemViewModel {						 
														 
}														 
//#endregion											 
