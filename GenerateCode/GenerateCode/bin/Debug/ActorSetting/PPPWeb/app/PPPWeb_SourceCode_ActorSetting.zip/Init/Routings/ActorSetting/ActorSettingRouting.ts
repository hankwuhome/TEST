//#region Common Import																
import { NgModule } from '@angular/core';											
import { RouterModule, Routes } from '@angular/router';								
//#endregion																			
																						
//#region Custom Import																
import { BaseController } from '../../../Controllers/ActorSetting/BaseController';			
import { SearchListController } from '../../../Controllers/ActorSetting/SearchListController';
import { DetailController } from '../../../Controllers/ActorSetting/DetailController';		
//#endregion																			
																						
//#region Definition																	
const setRoutes: Routes = [															
    {																				
        path: '',																	
        component: BaseController,													
        children: [																	
            { path: 'ActorSetting/searchlist', component: SearchListController },				
            { path: 'ActorSetting/editdetail/:Param', component: DetailController },			
        ]																			
    }																				
];																					
@NgModule({																			
    imports: [RouterModule.forChild(setRoutes)],										
    exports: [RouterModule]															
})																					
//#endregion																			
																						
//#region Class																		
export class ActorSettingRouting { }															
//#endregion																			
